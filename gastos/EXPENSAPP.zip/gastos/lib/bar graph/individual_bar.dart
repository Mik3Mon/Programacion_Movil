class IndividualBar{
  final int x;//position on x axis
  final double y;// amount in $

  IndividualBar({required this.x,required this.y});
}